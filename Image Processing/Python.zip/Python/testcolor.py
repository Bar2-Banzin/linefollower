from tests import test_car_color
# Choose Between 2 Colors
# For A color to be Good A Rectangular Mask Must be Drawn
test_car_color('./assets/colorgradient/3.jpeg', [0, 255, 0])
test_car_color('./assets/colorgradient/4.jpeg', [0, 0, 225])