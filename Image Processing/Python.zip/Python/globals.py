def debug_code(debug_parm=False):
    global debug
    debug = debug_parm
    return


def test_code(test_parm=False):
    global test
    test = test_parm
    return
