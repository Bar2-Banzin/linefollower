# track = cv2.imread('./assets/track/1.png')
# track = cv2.imread('./assets/track/1.png')


# # BGR to RGB
# track_RGB = cv2.cvtColor(track, cv2.COLOR_BGR2RGB)

# extract_lines(track_RGB)
